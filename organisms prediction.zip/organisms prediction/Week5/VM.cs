﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace OrgamismsPrediction
{

 
    class VM : INotifyPropertyChanged
    {
        const string DIRNAME = "PROG8010";
        const string FILENAME = "Organismsfile.txt";

        public int Organismnumb
        {
            get { return _organismnumb; }
            set { _organismnumb = value; OnPropertyChanged(); }
        }
        private int _organismnumb;

        public float Increment
        {
            get { return _increment; }
            set { _increment = value; OnPropertyChanged(); }
        }
        private float _increment;

        public float Resultinc
        {
            get { return _resultinc; }
            set { _resultinc = value; OnPropertyChanged(); }
        }
        private float _resultinc;

        public float Totalnumb
        {
            get { return _totalnumb; }
            set { _totalnumb = value; OnPropertyChanged(); }
        }
        private float _totalnumb;

        public List<Data> MyList
        {
            get { return _myList; }
            set { _myList = value; OnPropertyChanged(); }
        }
        List<Data> _myList = new List<Data>();

        public VM()
        {
            int i = 1;
            while(i < 366)
            {
               Data d = new Data();
                d.Value1 = i;
                
                _myList.Add(d);
                i++;
            }
 
        }

        public void Predict()
        {
             
            //try
            {
             //   Data d =new MyList;
              //float  x= d.Tofloat([])
                    Resultinc = (_increment / 100) * _organismnumb * 2;
                Totalnumb = (_organismnumb + Resultinc);


            }

        }
        public void clean()
        {
            Resultinc = 0;
            Totalnumb = 0;
        }
        public void Save()
        {
            string path = System.Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData);

            string fullpath = Path.Combine(path, DIRNAME);
            Directory.CreateDirectory(fullpath);

            string fullname = Path.Combine(fullpath, FILENAME);
            StreamWriter record = File.AppendText(fullname);

            
            
            foreach (Data d in MyList)
            {
                record.WriteLine(d.ToString());
            }

            record.Close();
        }

        #region PropertyChanged
        public event PropertyChangedEventHandler PropertyChanged;
        private void OnPropertyChanged([CallerMemberName]string caller = null)
        {
            // make sure only to call this if the value actually changes

            var handler = PropertyChanged;
            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(caller));
            }
        }
        #endregion

    }
}
